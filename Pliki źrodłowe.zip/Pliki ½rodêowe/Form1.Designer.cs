﻿namespace MartaGlowackaZadDom2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tabControlAnimals = new System.Windows.Forms.TabControl();
            this.dataGridViewAnimals = new System.Windows.Forms.DataGridView();
            this.species = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.breed = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.age = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fee = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.comboBoxPlace = new System.Windows.Forms.ComboBox();
            this.buttonTakeOut = new System.Windows.Forms.Button();
            this.textBoxMoney = new System.Windows.Forms.TextBox();
            this.labelPlace = new System.Windows.Forms.Label();
            this.labelMoney = new System.Windows.Forms.Label();
            this.labelInfo = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonDelete = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.labelDistance = new System.Windows.Forms.Label();
            this.textBoxDistance = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAnimals)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControlAnimals
            // 
            this.tabControlAnimals.Location = new System.Drawing.Point(632, 158);
            this.tabControlAnimals.Name = "tabControlAnimals";
            this.tabControlAnimals.SelectedIndex = 0;
            this.tabControlAnimals.Size = new System.Drawing.Size(453, 359);
            this.tabControlAnimals.TabIndex = 1;
            // 
            // dataGridViewAnimals
            // 
            this.dataGridViewAnimals.AllowUserToDeleteRows = false;
            this.dataGridViewAnimals.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewAnimals.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.species,
            this.breed,
            this.name,
            this.age,
            this.fee});
            this.dataGridViewAnimals.Location = new System.Drawing.Point(22, 158);
            this.dataGridViewAnimals.Name = "dataGridViewAnimals";
            this.dataGridViewAnimals.ReadOnly = true;
            this.dataGridViewAnimals.RowTemplate.Height = 24;
            this.dataGridViewAnimals.Size = new System.Drawing.Size(584, 359);
            this.dataGridViewAnimals.TabIndex = 2;
            // 
            // species
            // 
            this.species.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.species.HeaderText = "Gatunek";
            this.species.Name = "species";
            this.species.ReadOnly = true;
            // 
            // breed
            // 
            this.breed.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.breed.HeaderText = "Rasa";
            this.breed.Name = "breed";
            this.breed.ReadOnly = true;
            // 
            // name
            // 
            this.name.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.name.HeaderText = "Imię";
            this.name.Name = "name";
            this.name.ReadOnly = true;
            // 
            // age
            // 
            this.age.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.age.HeaderText = "Wiek";
            this.age.Name = "age";
            this.age.ReadOnly = true;
            // 
            // fee
            // 
            this.fee.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.fee.HeaderText = "Tyle zarobisz";
            this.fee.Name = "fee";
            this.fee.ReadOnly = true;
            // 
            // comboBoxPlace
            // 
            this.comboBoxPlace.FormattingEnabled = true;
            this.comboBoxPlace.Items.AddRange(new object[] {
            "Park",
            "Las",
            "Miasto"});
            this.comboBoxPlace.Location = new System.Drawing.Point(283, 556);
            this.comboBoxPlace.Name = "comboBoxPlace";
            this.comboBoxPlace.Size = new System.Drawing.Size(121, 24);
            this.comboBoxPlace.TabIndex = 3;
            // 
            // buttonTakeOut
            // 
            this.buttonTakeOut.Location = new System.Drawing.Point(22, 535);
            this.buttonTakeOut.Name = "buttonTakeOut";
            this.buttonTakeOut.Size = new System.Drawing.Size(214, 45);
            this.buttonTakeOut.TabIndex = 5;
            this.buttonTakeOut.Text = "Weź je na spacer";
            this.buttonTakeOut.UseVisualStyleBackColor = true;
            this.buttonTakeOut.Click += new System.EventHandler(this.buttonTakeOut_Click);
            // 
            // textBoxMoney
            // 
            this.textBoxMoney.Enabled = false;
            this.textBoxMoney.Location = new System.Drawing.Point(985, 27);
            this.textBoxMoney.Name = "textBoxMoney";
            this.textBoxMoney.Size = new System.Drawing.Size(100, 22);
            this.textBoxMoney.TabIndex = 6;
            this.textBoxMoney.Text = "nic nie masz";
            // 
            // labelPlace
            // 
            this.labelPlace.AutoSize = true;
            this.labelPlace.Location = new System.Drawing.Point(280, 535);
            this.labelPlace.Name = "labelPlace";
            this.labelPlace.Size = new System.Drawing.Size(110, 17);
            this.labelPlace.TabIndex = 7;
            this.labelPlace.Text = "Miejsce spaceru";
            // 
            // labelMoney
            // 
            this.labelMoney.AutoSize = true;
            this.labelMoney.Location = new System.Drawing.Point(919, 27);
            this.labelMoney.Name = "labelMoney";
            this.labelMoney.Size = new System.Drawing.Size(60, 17);
            this.labelMoney.TabIndex = 8;
            this.labelMoney.Text = "Zarobki:";
            // 
            // labelInfo
            // 
            this.labelInfo.AutoSize = true;
            this.labelInfo.Font = new System.Drawing.Font("Somebercum Sans Serif", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelInfo.Location = new System.Drawing.Point(184, 9);
            this.labelInfo.Name = "labelInfo";
            this.labelInfo.Size = new System.Drawing.Size(581, 89);
            this.labelInfo.TabIndex = 9;
            this.labelInfo.Text = "Wyprowadzaj i zarabiaj!";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 129);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(142, 17);
            this.label1.TabIndex = 10;
            this.label1.Text = "Na spacer zabierasz:";
            // 
            // buttonDelete
            // 
            this.buttonDelete.Location = new System.Drawing.Point(455, 535);
            this.buttonDelete.Name = "buttonDelete";
            this.buttonDelete.Size = new System.Drawing.Size(151, 45);
            this.buttonDelete.TabIndex = 11;
            this.buttonDelete.Text = "Usuń z listy";
            this.buttonDelete.UseVisualStyleBackColor = true;
            this.buttonDelete.Click += new System.EventHandler(this.buttonDelete_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 9);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(109, 114);
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            // 
            // labelDistance
            // 
            this.labelDistance.AutoSize = true;
            this.labelDistance.Location = new System.Drawing.Point(826, 57);
            this.labelDistance.Name = "labelDistance";
            this.labelDistance.Size = new System.Drawing.Size(153, 17);
            this.labelDistance.TabIndex = 13;
            this.labelDistance.Text = "Przewidywany dystans:";
            // 
            // textBoxDistance
            // 
            this.textBoxDistance.Enabled = false;
            this.textBoxDistance.Location = new System.Drawing.Point(985, 57);
            this.textBoxDistance.Name = "textBoxDistance";
            this.textBoxDistance.Size = new System.Drawing.Size(100, 22);
            this.textBoxDistance.TabIndex = 14;
            this.textBoxDistance.Text = "0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1100, 603);
            this.Controls.Add(this.textBoxDistance);
            this.Controls.Add(this.labelDistance);
            this.Controls.Add(this.buttonDelete);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelInfo);
            this.Controls.Add(this.labelMoney);
            this.Controls.Add(this.labelPlace);
            this.Controls.Add(this.textBoxMoney);
            this.Controls.Add(this.buttonTakeOut);
            this.Controls.Add(this.comboBoxPlace);
            this.Controls.Add(this.dataGridViewAnimals);
            this.Controls.Add(this.tabControlAnimals);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAnimals)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TabControl tabControlAnimals;
        private System.Windows.Forms.DataGridView dataGridViewAnimals;
        private System.Windows.Forms.ComboBox comboBoxPlace;
        private System.Windows.Forms.Button buttonTakeOut;
        private System.Windows.Forms.TextBox textBoxMoney;
        private System.Windows.Forms.Label labelPlace;
        private System.Windows.Forms.Label labelMoney;
        private System.Windows.Forms.Label labelInfo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewTextBoxColumn species;
        private System.Windows.Forms.DataGridViewTextBoxColumn breed;
        private System.Windows.Forms.DataGridViewTextBoxColumn name;
        private System.Windows.Forms.DataGridViewTextBoxColumn age;
        private System.Windows.Forms.DataGridViewTextBoxColumn fee;
        private System.Windows.Forms.Button buttonDelete;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label labelDistance;
        private System.Windows.Forms.TextBox textBoxDistance;
    }
}

