﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;

namespace MartaGlowackaZadDom2
{
    public class Dog : Animal
    {
        public bool HasCollar { get; set; }
        public string Species { get; set; }

        public Dog(string name, int age, bool hasCollar) :base(name, age)
        {
            HasCollar = hasCollar;
            Species = "cur";
            Fee = 10;
            Effort = 6;
        }

      

        public override SoundPlayer GiveSound()
        {
            return null;
        }

        public String Fetch()
        {
            //aport
            return "I am running! For it!";
        }

    }
}
