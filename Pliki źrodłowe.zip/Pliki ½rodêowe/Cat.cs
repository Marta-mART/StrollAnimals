﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;

namespace MartaGlowackaZadDom2
{
    public class Cat : Animal
    {
        public bool LikesMilk { get; set; }
        public string Species { get; set; }
        

        //konstruktor
        public Cat(string name, int age, bool likesMilk) : base(name, age)
        {
            LikesMilk = likesMilk;
            Species = "cat";
            Fee = 6;
            DailyDistance = 3;
            Effort = 2;
        }

        public override SoundPlayer GiveSound()
        {
            return null;
        }

        public String Scratch()
        {
            //drapanie
            return "Srrrratch";
        }
    }
}
