﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;

namespace MartaGlowackaZadDom2
{
    public class Boxer : Dog
    {
        public string breed { get; set; }
        public int Strength { get; set; }

        public Boxer(string name, int age, bool hasCollar, int strength) : base(name, age, hasCollar)
        {
            Strength = strength;
            Breed = "boxer";
            DailyDistance = 13;
        }

        //Dodatkowa funkcjonalność - tylko dla boxera
        public String Bite()
        {
            return "Aaagrrr";
        }

        //Daj głos
        public override SoundPlayer GiveSound()
        {
           return new SoundPlayer(MartaGlowackaZadDom2.Properties.Resources.dog_boxer); 
   
        }
    }
}
