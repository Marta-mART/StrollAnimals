﻿namespace MartaGlowackaZadDom2
{
    partial class FormStrolling
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormStrolling));
            this.progressBarStrolling = new System.Windows.Forms.ProgressBar();
            this.labelStrolling = new System.Windows.Forms.Label();
            this.timerStrolling = new System.Windows.Forms.Timer(this.components);
            this.labelPlace = new System.Windows.Forms.Label();
            this.labelDistance = new System.Windows.Forms.Label();
            this.labelKm = new System.Windows.Forms.Label();
            this.pictureBoxAnimalsWalking = new System.Windows.Forms.PictureBox();
            this.timerSounds = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxAnimalsWalking)).BeginInit();
            this.SuspendLayout();
            // 
            // progressBarStrolling
            // 
            this.progressBarStrolling.Location = new System.Drawing.Point(56, 114);
            this.progressBarStrolling.Name = "progressBarStrolling";
            this.progressBarStrolling.Size = new System.Drawing.Size(299, 23);
            this.progressBarStrolling.TabIndex = 5;
            // 
            // labelStrolling
            // 
            this.labelStrolling.AutoSize = true;
            this.labelStrolling.Location = new System.Drawing.Point(53, 37);
            this.labelStrolling.Name = "labelStrolling";
            this.labelStrolling.Size = new System.Drawing.Size(158, 17);
            this.labelStrolling.TabIndex = 6;
            this.labelStrolling.Text = "Spacerujesz w miejscu: ";
            // 
            // timerStrolling
            // 
            this.timerStrolling.Tick += new System.EventHandler(this.timerStrolling_Tick);
            // 
            // labelPlace
            // 
            this.labelPlace.AutoSize = true;
            this.labelPlace.Location = new System.Drawing.Point(244, 37);
            this.labelPlace.Name = "labelPlace";
            this.labelPlace.Size = new System.Drawing.Size(13, 17);
            this.labelPlace.TabIndex = 7;
            this.labelPlace.Text = "-";
            // 
            // labelDistance
            // 
            this.labelDistance.AutoSize = true;
            this.labelDistance.Location = new System.Drawing.Point(53, 64);
            this.labelDistance.Name = "labelDistance";
            this.labelDistance.Size = new System.Drawing.Size(275, 17);
            this.labelDistance.TabIndex = 8;
            this.labelDistance.Text = "Zwierzęta sumarycznie pokonają dystans: ";
            // 
            // labelKm
            // 
            this.labelKm.AutoSize = true;
            this.labelKm.Location = new System.Drawing.Point(342, 64);
            this.labelKm.Name = "labelKm";
            this.labelKm.Size = new System.Drawing.Size(13, 17);
            this.labelKm.TabIndex = 9;
            this.labelKm.Text = "-";
            // 
            // pictureBoxAnimalsWalking
            // 
            this.pictureBoxAnimalsWalking.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBoxAnimalsWalking.BackgroundImage")));
            this.pictureBoxAnimalsWalking.Location = new System.Drawing.Point(86, 143);
            this.pictureBoxAnimalsWalking.Name = "pictureBoxAnimalsWalking";
            this.pictureBoxAnimalsWalking.Size = new System.Drawing.Size(242, 165);
            this.pictureBoxAnimalsWalking.TabIndex = 12;
            this.pictureBoxAnimalsWalking.TabStop = false;
            // 
            // timerSounds
            // 

            // 
            // FormStrolling
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(398, 336);
            this.ControlBox = false;
            this.Controls.Add(this.pictureBoxAnimalsWalking);
            this.Controls.Add(this.labelKm);
            this.Controls.Add(this.labelDistance);
            this.Controls.Add(this.labelPlace);
            this.Controls.Add(this.labelStrolling);
            this.Controls.Add(this.progressBarStrolling);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(416, 383);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(416, 383);
            this.Name = "FormStrolling";
            this.Text = "FormStrolling";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxAnimalsWalking)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ProgressBar progressBarStrolling;
        private System.Windows.Forms.Label labelStrolling;
        private System.Windows.Forms.Timer timerStrolling;
        private System.Windows.Forms.Label labelPlace;
        private System.Windows.Forms.Label labelDistance;
        private System.Windows.Forms.Label labelKm;
        private System.Windows.Forms.PictureBox pictureBoxAnimalsWalking;
        private System.Windows.Forms.Timer timerSounds;
    }
}