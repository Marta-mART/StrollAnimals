﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;

namespace MartaGlowackaZadDom2
{
    public abstract class Animal : ITiredAble
    {
        public string Breed { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public int Fee { get; set; }
        public int DailyDistance { get; set; }
        public int Effort { get; set; }
        public int Energy { get; set; } //in percent

        /// <summary>
        /// konstruktor domyślny
        /// </summary>
        public Animal()
        {

        }

        /// <summary>
        /// Konstruktor parametryczny
        /// </summary>
        /// <param name="name"></param>
        /// <param name="age"></param>
        public Animal(string name, int age)
        {
            Fee = 5;
            Name = name;
            Age = age;
            Breed = "no breed";
            DailyDistance = 10;
            Effort = 0;
            Energy = 100;
        }

        /// <summary>
        /// Przesłoniona metoda wirtualna - daj głos
        /// </summary>
        /// <returns></returns>
        public virtual SoundPlayer GiveSound()
        { return null; }

        public void GetTired()
        {
            Energy -= Effort;
        }
    }
}
