﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;

namespace MartaGlowackaZadDom2
{
    public class Pers : Cat
    {  
        public int Fluffiness { get; set; }
        public Pers(string name, int age, bool likesMilk, int fluffiness) : base(name, age, likesMilk)
        {
            Fluffiness = fluffiness;
            Breed = "pers";
            DailyDistance = 1;
        }

        //Dodatkowa funkcjonalność - tylko dla persa
        public String Complaining()
        {
            //narzekanie
            return "Oh no! Again?";
        }

        //Daj głos
        public override SoundPlayer  GiveSound()
        {
            return new SoundPlayer(MartaGlowackaZadDom2.Properties.Resources.cat_pers);
         
        }
    }
}
