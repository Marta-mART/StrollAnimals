﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;

namespace MartaGlowackaZadDom2
{
    public class Poodle : Dog
    {
        //Dodatkowa property - tylko dla pudli
        public string HairStyle { get; set; }

        public Poodle(string name, int age, bool hasCollar, string hairStyle) : base(name, age, hasCollar)
        {
            HairStyle = hairStyle;
            Breed = "poodle";
            DailyDistance = 8;
        }

        //Dodatkowa funkcjonalność - tylko dla pudli
        public String Down()
        {
            //waruj
            return "Tup tup";
        }

        //Daj głos
        public override SoundPlayer GiveSound()
        {
            return new SoundPlayer(MartaGlowackaZadDom2.Properties.Resources.dog_poodle);           
        }
    }
}
