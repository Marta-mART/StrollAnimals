﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;

namespace MartaGlowackaZadDom2
{
    public class Sphynx : Cat
    {
        
        public int TailLength { get; set; }
        public Sphynx(string name, int age, bool likesMilk, int tailLength) : base(name, age, likesMilk)
        {
            TailLength = tailLength;
            Breed = "sphynx";
            DailyDistance = 4;
        }

        //Dodatkowa funkcjonalność - tylko dla sphynxa
        public String Jump()
        {
            return "Hops";
        }

        //Daj głos
        public override SoundPlayer GiveSound()
        {
            return new SoundPlayer(MartaGlowackaZadDom2.Properties.Resources.cat_sphynx);

        }
    }
}
