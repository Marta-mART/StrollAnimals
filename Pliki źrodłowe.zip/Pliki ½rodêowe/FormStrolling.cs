﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MartaGlowackaZadDom2
{
    public partial class FormStrolling : Form
    {
        List<Animal> walkedAnimals;
        int strollDistance = 0;
        Thread soundThread;

        public FormStrolling()
        {
            InitializeComponent();
            timerStrolling.Start();
        }

        //konstruktor przyjmuje miejsce spaceru jako argument
        public FormStrolling(String place, List<Animal> walkedAnimals)
        {
           
            InitializeComponent();
            timerStrolling.Start();

            if (place != "") labelPlace.Text = place;
            else labelPlace.Text = "Tu i tam";


            this.walkedAnimals = walkedAnimals;
            foreach (Animal a in walkedAnimals)
            {
                strollDistance += a.DailyDistance;                
            }

            labelKm.Text = strollDistance + " km";


            soundThread = new Thread(new ThreadStart(ThreadProc));
            soundThread.Start();
        }


        /// <summary>
        /// Ładowanie progress bara ze spacerem
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void timerStrolling_Tick(object sender, EventArgs e)
        {
            //czas spaceru uzależniony jest od tego, ile zwierząt zabierasz, a właściwie, ile robią one sumarycznie km
            if (strollDistance > 80) timerStrolling.Interval = 300;
            else if (strollDistance > 20) timerStrolling.Interval = 100;
            else if (strollDistance < 20) timerStrolling.Interval = 40;
                       

            progressBarStrolling.Increment(1);
            //jeśli spacer dobiegnie końca, czyli progress bar się załaduje, wyłączmy okno spaceru
            if (progressBarStrolling.Value == progressBarStrolling.Maximum)
            {
                //Zamknięcie forma ze spacerkiem
                this.Close();
                //wątek z dźwiękami zakończony
                soundThread.Abort();
                
            }            
        }



        //Wątek odtwarza dźwięki
        private void ThreadProc()
        {
            SoundPlayer soundAnimal;
            foreach (Animal a in walkedAnimals)
            {
                soundAnimal = a.GiveSound();
                soundAnimal.Play();
                Thread.Sleep(1500);
                soundAnimal.Stop();
            }
            
        }
    }
}
