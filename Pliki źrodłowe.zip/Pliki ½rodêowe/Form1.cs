﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MartaGlowackaZadDom2
{
    public partial class Form1 : Form
    {
        static public int distance = 0;

        //lista wszystkich zwierząt dodawanych w programie
        List<Animal> listOfAnimals = new List<Animal>();

        //lista zwierząt, które możesz wziąć na spacer
        List<Animal> listOfWalkedAnimals = new List<Animal>();

        List<ProgressBar> fullness = new List<ProgressBar>();

        public Form1()
        {
            //dodanie zwierząt do listy
            InitializeComponent();
            listOfAnimals.Add(new Pers("Steffi", 12, false, 3));
            listOfAnimals.Add(new Pers("Jugo", 4, true, 2));
            listOfAnimals.Add(new Pers("Harik", 5, true, 7));
            listOfAnimals.Add(new Sphynx("Daisy", 2, false, 5));
            listOfAnimals.Add(new Sphynx("Dara", 10, false, 15));
            listOfAnimals.Add(new Sphynx("Luu", 15, true, 25));
            listOfAnimals.Add(new Boxer("Herman", 6, false, 20));
            listOfAnimals.Add(new Boxer("Rex", 15, false, 12));
            listOfAnimals.Add(new Boxer("Axel", 25, true, 22));
            listOfAnimals.Add(new Poodle("Sisi", 6, false, "big"));
            listOfAnimals.Add(new Poodle("Wera", 6, true, "lagoona"));
            listOfAnimals.Add(new Poodle("Komo", 7, true, "modern"));

            for(int i=0; i < listOfAnimals.Count; i++)
            {
                ProgressBar p = new ProgressBar();
                fullness.Add(p);

                p.Location = new Point(0, 0);
                p.Size = new Size(100, 10);
                // Set the initial value of the ProgressBar.
                p.Value = 100;
                // Set the Step property to a value of 1 to represent each file being copied.
                p.Step = 1;
                p.Maximum = 100;
            }
                 

            //dodanie reprezentacji zwierząt do panelu
            AddAnimalToTabbedPanel();
        }

        /// <summary>
        /// Dodanie kotów i psów do odpowiednich paneli i ustawienie dla nich przycisków
        /// </summary>
        private void AddAnimalToTabbedPanel()
        {
            //zrobienie strony dla kotów
            string catTitle = "Cats Room ";
            TabPage catTabPage = new TabPage(catTitle);
            tabControlAnimals.TabPages.Add(catTabPage);

            //zrobienie strony dla psów
            string dogTitle = "Dogs Room ";
            TabPage dogTabPage = new TabPage(dogTitle);
            tabControlAnimals.TabPages.Add(dogTabPage);

            //ustawienie panelu dla kotów tak, aby przyciski były rozmieszczane w rzędach
            FlowLayoutPanel catFlowLayoutPanel = new FlowLayoutPanel();
            catFlowLayoutPanel.Dock = DockStyle.Fill;

            //ustawienie panelu dla psów tak, aby przyciski były rozmieszczane w rzędach
            FlowLayoutPanel dogFlowLayoutPanel = new FlowLayoutPanel();
            dogFlowLayoutPanel.Dock = DockStyle.Fill;

            //dla każdego zwierzęcia z programu, który jest kotem ustawiamy przysisk na odpowiedniej zakładce
            foreach (Animal c in listOfAnimals)
            {
                if (c is Cat)
                {
                    Button b = new Button();
                    b.Size = new Size(100, 100);
                    b.Text = c.Breed + " " + c.Name;
                    if (c.Breed == "sphynx") b.Image = MartaGlowackaZadDom2.Properties.Resources.sphynx;
                    if (c.Breed == "pers") b.Image = MartaGlowackaZadDom2.Properties.Resources.persian;
                                   

                    b.Tag = c;
                    b.Click += new EventHandler(UpdateStrollList); 
                    catFlowLayoutPanel.Controls.Add(b);
                }
                //dla każdego zwierzęcia z programu, który jest psem ustawiamy przysisk na odpowiedniej zakładce  
                if (c is Dog)
                {
                    Button b = new Button();
                    b.Size = new Size(100, 100);
                    b.Text = c.Breed + " " + c.Name;
                    if (c.Breed == "boxer") b.Image = MartaGlowackaZadDom2.Properties.Resources.boxer;
                    if (c.Breed == "poodle") b.Image = MartaGlowackaZadDom2.Properties.Resources.poodle;
                  
                    b.Tag = c;
                    b.Click += new EventHandler(UpdateStrollList);
                    dogFlowLayoutPanel.Controls.Add(b); 
                }
            }

            for(int i=0; i<listOfAnimals.Count/2; i++)
            {
                catFlowLayoutPanel.Controls.Add(fullness.ElementAt(i));
            }
            for (int i = listOfAnimals.Count / 2; i < listOfAnimals.Count; i++)
            {
                dogFlowLayoutPanel.Controls.Add(fullness.ElementAt(i));
            }


            //Dodanie powstałych powyżej layoutów
            catTabPage.Controls.Add(catFlowLayoutPanel);
            dogTabPage.Controls.Add(dogFlowLayoutPanel);
           
        }

        /// <summary>
        /// Aktualizacja listy widocznej w dataGridView po kliknięciu na przycisk
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UpdateStrollList(object sender, EventArgs e)
        {
            //obiektem wywołującym zdarzenie jest przycisk przekazywany przez argument
            Button b = (Button)sender;

            //przycisk ten niesie informacje o tagu, który za pomocą rzutowania typu w górę przerabiamy na zwierzę
            Animal a = (Animal)b.Tag;

            //wycinamy nazwę rasy dla zwierzęcia
            String breed = b.Tag.ToString().Split('.')[1];

            //dodajemy wiersz
            int n = dataGridViewAnimals.Rows.Add();   
            
            //w pierwszej komórce decydujemy, czy wpiszemy kot czy pies 
            if(breed.Equals("Boxer") || breed.Equals("Poodle"))
            {
                dataGridViewAnimals.Rows[n].Cells[0].Value = "dog";
            }        
            else if (breed.Equals("Pers") || breed.Equals("Sphynx"))
            {
                dataGridViewAnimals.Rows[n].Cells[0].Value = "cat";
            }

            distance += a.DailyDistance;
            textBoxDistance.Text = distance.ToString();

            //w kolejnych komórkach wypełniamy dane o zwierzęciu
            dataGridViewAnimals.Rows[n].Cells[1].Value = breed;
            dataGridViewAnimals.Rows[n].Cells[2].Value = a.Name;
            dataGridViewAnimals.Rows[n].Cells[3].Value = a.Age;
            dataGridViewAnimals.Rows[n].Cells[4].Value = a.Fee;

            //dodajemy zwierzę do listy, która zawiera zwierzęta wyprowadzane na spacer
            listOfWalkedAnimals.Add(a);            
                   
        }

      
        /// <summary>
        /// Zabieranie zwierząt na spacer i otworzenie okna
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonTakeOut_Click(object sender, EventArgs e)
        {
            if(listOfWalkedAnimals.Count != 0)
            {
                FormStrolling formStrolling = new FormStrolling(comboBoxPlace.Text, listOfWalkedAnimals);
                formStrolling.Show();
                EarnMoney();                
            }

            //Obniżanie głodu zwierzętom, które są wyprowadzane
            for (int i = 0; i < listOfWalkedAnimals.Count; i++)
            {
                string animalName = listOfWalkedAnimals.ElementAt(i).Name.ToString();
                int item = listOfAnimals.IndexOf(listOfAnimals.Find(x => x.Name == animalName));
                if (fullness.ElementAt(item).Value > 10)
                {
                    fullness.ElementAt(item).Increment(-1 * listOfAnimals.ElementAt(item).Effort);
                    listOfAnimals.ElementAt(item).GetTired();
                }
                else MessageBox.Show("Bez przesady? Chcesz zajechać zwierzę?!");
            }
        }       

        //liczba zarobionych pieniędzy
        int money = 0;
        /// <summary>
        /// Zarabianie pieniędzy po wyprowadzeniu zwierząt na spacer
        /// </summary>
        public void EarnMoney()
        {
            //dodanie tylu pieniędzy, ile warte jest wyprowadzenie psa lub kota
            foreach(Animal a in listOfWalkedAnimals)
            {
                money += a.Fee;
            }
            //wyświetl w textBoxie, ile zarobiłeś
            textBoxMoney.Text = money + " zł";
        }

        /// <summary>
        /// Usunięcie z listy zaznaczonego wiersza ze zwierzeciem
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonDelete_Click(object sender, EventArgs e)
        {
             
            foreach (DataGridViewRow item in this.dataGridViewAnimals.SelectedRows)
            {
                //próba usunięcia zwierzęcia
                try
                {
                    if (item.Index >= 0)
                    {
                        //odjęcie od przewidywanego sumerycznego dystansu, dystansy zwierzęcia usuwanego
                        distance -= (listOfWalkedAnimals.ElementAt(item.Index)).DailyDistance;
                        textBoxDistance.Text = distance.ToString();

                        //Usunięcie zwierzęcia z listy
                        listOfWalkedAnimals.RemoveAt(item.Index);

                        //Komunikat o usuwaniu
                        MessageBox.Show("Usuwamy z listy nr " + item.Index);                       

                        //Usunięcie z data grid zwierzęcia
                        dataGridViewAnimals.Rows.RemoveAt(item.Index);                        
                    }
                    
                }
                //obsługa wyjątku poprzez dodanie pustego wiersza
                catch (System.InvalidOperationException)
                {
                    dataGridViewAnimals.Rows.Add();
                }
             }
        
        }

       
    }
}
